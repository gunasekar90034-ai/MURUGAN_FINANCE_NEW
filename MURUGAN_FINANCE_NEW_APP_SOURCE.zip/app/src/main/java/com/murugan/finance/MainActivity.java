package com.murugan.finance;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.*;
import android.content.Intent;
import android.net.Uri;

public class MainActivity extends Activity {
  @Override public void onCreate(Bundle b) {
    super.onCreate(b);
    WebView w = new WebView(this);
    w.getSettings().setJavaScriptEnabled(true);
    w.getSettings().setDomStorageEnabled(true);
    w.addJavascriptInterface(new SmsBridge(), "AndroidSMS");
    w.setWebChromeClient(new WebChromeClient());
    w.loadUrl("file:///android_asset/index.html");
    setContentView(w);
  }
  public class SmsBridge {
    @JavascriptInterface public void send(String phone, String message) {
      runOnUiThread(() -> {
        try {
          Intent i = new Intent(Intent.ACTION_SENDTO);
          i.setData(Uri.parse("smsto:" + Uri.encode(phone)));
          i.putExtra("sms_body", message);
          startActivity(i);
        } catch (Exception ignored) { }
      });
    }
  }
}
